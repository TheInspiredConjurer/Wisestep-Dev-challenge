package com.example.wisestepassignment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.wisestepassignment.dto.UserDto;
import com.example.wisestepassignment.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserService userServ;
	
	@PostMapping("/add")
	public ResponseEntity<UserDto> addNewUser(UserDto userDto) {
		
		userDto = userServ.addNewUser(userDto);
		
		return new ResponseEntity<UserDto>(userDto, HttpStatus.OK);
	}

}
