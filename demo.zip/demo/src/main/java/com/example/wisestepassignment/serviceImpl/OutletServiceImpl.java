package com.example.wisestepassignment.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.wisestepassignment.dto.OutletDto;
import com.example.wisestepassignment.entity.Outlet;
import com.example.wisestepassignment.repository.OutletRepository;
import com.example.wisestepassignment.service.OutletService;

@Component
public class OutletServiceImpl implements OutletService {
	
	@Autowired
	private OutletRepository outletRepo;

	@Override
	public List<OutletDto> getAllOutletsInfo() {
		List<Outlet> allListOfOutlets = outletRepo.findAll();
		List<OutletDto> allListOfOutletDtos = Outlet.convertEntityListToDtoList(allListOfOutlets);
		return allListOfOutletDtos;
	}

}
