package com.example.wisestepassignment.dto;

import java.util.List;

import com.example.wisestepassignment.entity.Outlet;
import com.example.wisestepassignment.entity.Reservation;
import com.example.wisestepassignment.entity.Trip;
import com.example.wisestepassignment.entity.User;
import com.example.wisestepassignment.entity.Vehicle;

public class OutletDto {
	
	private String outletId;
	
	private String outletName;
	
	private String location;
	
	private List<Vehicle> vehicles;
	
	private List<User> users;
	
	private List<Reservation> reservations;

	public String getOutletId() {
		return outletId;
	}

	public void setOutletId(String outletId) {
		this.outletId = outletId;
	}

	public String getOutletName() {
		return outletName;
	}

	public void setOutletName(String outletName) {
		this.outletName = outletName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public List<Reservation> getReservations() {
		return reservations;
	}

	public void setReservations(List<Reservation> reservations) {
		this.reservations = reservations;
	}
	
	public Outlet convertDtoToEntity(OutletDto outletDto) {
		Outlet outletEntity = new Outlet();
		outletEntity.setOutletName(outletDto.getOutletName());
		return outletEntity;
		
	}

	public OutletDto(String outletId, String outletName, String location, List<Vehicle> vehicles, List<User> users,
			List<Reservation> reservations) {
		super();
		this.outletId = outletId;
		this.outletName = outletName;
		this.location = location;
		this.vehicles = vehicles;
		this.users = users;
		this.reservations = reservations;
	}

	public OutletDto(String outletName, String location) {
		super();
		this.outletName = outletName;
		this.location = location;
	}

	public OutletDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
