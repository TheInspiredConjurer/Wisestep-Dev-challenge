package com.example.wisestepassignment.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Location {
	
	@Id
	private String locationId;
	
	private String locationName;
	
	private Double latitudeOfLocation;
	
	private Double longitudeOfLocation;
	
	@ManyToMany
	private List<Trip> trip;

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public Double getLatitudeOfLocation() {
		return latitudeOfLocation;
	}

	public void setLatitudeOfLocation(Double latitudeOfLocation) {
		this.latitudeOfLocation = latitudeOfLocation;
	}

	public Double getLongitudeOfLocation() {
		return longitudeOfLocation;
	}

	public void setLongitudeOfLocation(Double longitudeOfLocation) {
		this.longitudeOfLocation = longitudeOfLocation;
	}

	public List<Trip> getTrip() {
		return trip;
	}

	public void setTrip(List<Trip> trip) {
		this.trip = trip;
	}

	public Location() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}