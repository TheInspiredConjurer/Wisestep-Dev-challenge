package com.example.wisestepassignment.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Reservation {
	
	@Id
	private String reservationId;
	
	private String reservationNumber;
	
	private LocalDateTime timeOfReservation;
	
	private Boolean reservationStatus; // is the particular outlet as well as the particular vehicle reserved or not
	
	@ManyToOne
	private User user;
	
	@ManyToOne
	private Outlet outlet;
	
	@OneToOne
	private Vehicle vehicle;

	public String getReservationId() {
		return reservationId;
	}

	public void setReservationId(String reservationId) {
		this.reservationId = reservationId;
	}

	public String getReservationNumber() {
		return reservationNumber;
	}

	public void setReservationNumber(String reservationNumber) {
		this.reservationNumber = reservationNumber;
	}

	public LocalDateTime getTimeOfReservation() {
		return timeOfReservation;
	}

	public void setTimeOfReservation(LocalDateTime timeOfReservation) {
		this.timeOfReservation = timeOfReservation;
	}

	public Boolean getReservationStatus() {
		return reservationStatus;
	}

	public void setReservationStatus(Boolean reservationStatus) {
		this.reservationStatus = reservationStatus;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Outlet getOutlet() {
		return outlet;
	}

	public void setOutlet(Outlet outlet) {
		this.outlet = outlet;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public Reservation() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
