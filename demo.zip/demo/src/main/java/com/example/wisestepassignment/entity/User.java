package com.example.wisestepassignment.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import com.example.wisestepassignment.dto.UserDto;

@Entity
public class User {
	
	@Id
	private String userId;
	
	private String userName;
	
	private String location;
	
	@ManyToMany(mappedBy = "users")
	private List<Outlet> outlets;
	
	@OneToMany(mappedBy = "user")
	private List<Trip> trips;
	
	@OneToMany(mappedBy = "user")
	private List<Reservation> reservations;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<Outlet> getOutlets() {
		return outlets;
	}

	public void setOutlets(List<Outlet> outlets) {
		this.outlets = outlets;
	}

	public List<Trip> getTrips() {
		return trips;
	}

	public void setTrips(List<Trip> trips) {
		this.trips = trips;
	}

	public List<Reservation> getReservations() {
		return reservations;
	}

	public void setReservations(List<Reservation> reservations) {
		this.reservations = reservations;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public UserDto convertEntityToDto(User user) {
		UserDto userDto = new UserDto();
		userDto.setUserName(user.getUserName());
		return userDto;
	}
	

}
