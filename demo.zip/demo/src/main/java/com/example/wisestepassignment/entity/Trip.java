package com.example.wisestepassignment.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Trip {
	
public enum tripStatusType {
	STARTED, CANCELLED, COMPLETED 
}
	
	@Id
	private String tripId;
	
	private String tripNumber;
	
	private Double priceOfTrip;
	
	@Enumerated(EnumType.STRING)
	private tripStatusType tripStatus;
	
	@ManyToOne
	private Vehicle vehicle;
	
	@ManyToOne
	private User user;
	
	@ManyToMany
	private List<Location> location;

	public String getTripId() {
		return tripId;
	}

	public void setTripId(String tripId) {
		this.tripId = tripId;
	}

	public String getTripNumber() {
		return tripNumber;
	}

	public void setTripNumber(String tripNumber) {
		this.tripNumber = tripNumber;
	}

	public Double getPriceOfTrip() {
		return priceOfTrip;
	}

	public void setPriceOfTrip(Double priceOfTrip) {
		this.priceOfTrip = priceOfTrip;
	}

	public tripStatusType getTripStatus() {
		return tripStatus;
	}

	public void setTripStatus(tripStatusType tripStatus) {
		this.tripStatus = tripStatus;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<Location> getLocation() {
		return location;
	}

	public void setLocation(List<Location> location) {
		this.location = location;
	}

	public Trip() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
