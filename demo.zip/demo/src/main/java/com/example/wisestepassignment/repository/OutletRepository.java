package com.example.wisestepassignment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.wisestepassignment.entity.Outlet;

public interface OutletRepository extends JpaRepository<Outlet, String> {

}
