package com.example.wisestepassignment.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Vehicle {
	
	@Id
	private String vehicleId;
	
	private String vehicleName;
	
	private Boolean isVehicleAvailable;
	
	@OneToMany
	private List<Trip> listOfTrips;
	
	@ManyToMany
	private List<Outlet> outlets;

	public String getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(String vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public Boolean getIsVehicleAvailable() {
		return isVehicleAvailable;
	}

	public void setIsVehicleAvailable(Boolean isVehicleAvailable) {
		this.isVehicleAvailable = isVehicleAvailable;
	}

	public List<Trip> getListOfTrips() {
		return listOfTrips;
	}

	public void setListOfTrips(List<Trip> listOfTrips) {
		this.listOfTrips = listOfTrips;
	}

	public List<Outlet> getOutlets() {
		return outlets;
	}

	public void setOutlets(List<Outlet> outlets) {
		this.outlets = outlets;
	}

	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
