package com.example.wisestepassignment.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.wisestepassignment.dto.OutletDto;

@Service
public interface OutletService {
	
	public List<OutletDto> getAllOutletsInfo();

}
