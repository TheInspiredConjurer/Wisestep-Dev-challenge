package com.example.wisestepassignment.serviceImpl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.wisestepassignment.dto.UserDto;
import com.example.wisestepassignment.entity.User;
import com.example.wisestepassignment.repository.UserRepository;
import com.example.wisestepassignment.service.UserService;

@Component
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userServiceRepo;
	

	@Override
	@Transactional
	public UserDto addNewUser(UserDto userDto) {
		User u = (userServiceRepo.save(userDto.convertDtoToEntity(userDto)));
		userDto = u.convertEntityToDto(u);
		return userDto;
	}

}
