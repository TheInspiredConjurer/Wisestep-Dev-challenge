package com.example.wisestepassignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.wisestepassignment.dto.OutletDto;
import com.example.wisestepassignment.dto.ReservationDto;
import com.example.wisestepassignment.service.OutletService;

@RestController
public class ReservationController {
	
	@Autowired
	private OutletService outletServ;
	
	@GetMapping("/all")
	public ResponseEntity<List<OutletDto>> getAllOutletsInfo() {
		
		List<OutletDto> allOutlets = outletServ.getAllOutletsInfo();
		
		return new ResponseEntity<List<OutletDto>>(allOutlets, HttpStatus.OK); 
	}
	
	
	@PatchMapping("/updateReservation/{id}")
	public ResponseEntity<String> updateReservationInfo(@RequestBody ReservationDto reservationDto) {
		
		String Response = outletServ.updateReservationDto(reservationDto);
		
		return new ResponseEntity<String>(Response, HttpStatus.OK); 
	}

}
