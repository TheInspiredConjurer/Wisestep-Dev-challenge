package com.example.wisestepassignment.dto;

public class ReservationDto {
	
	private Integer userId;
	
	private Integer reservationId;

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getReservationId() {
		return reservationId;
	}

	public void setReservationId(Integer reservationId) {
		this.reservationId = reservationId;
	}
	
	

}
