package com.example.wisestepassignment.service;

import org.springframework.stereotype.Service;

import com.example.wisestepassignment.dto.UserDto;

@Service
public interface UserService {
	
	public UserDto addNewUser(UserDto userDto);

}
