package com.example.wisestepassignment.entity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import com.example.wisestepassignment.dto.OutletDto;

@Entity
public class Outlet {

	@Id
	private String outletId;

	private String outletName;

	private String location;

	@ManyToMany
	private List<Vehicle> vehicles;

	@ManyToMany
	private List<User> users;

	@OneToMany
	private List<Reservation> reservations;

	public String getOutletId() {
		return outletId;
	}

	public void setOutletId(String outletId) {
		this.outletId = outletId;
	}

	public String getOutletName() {
		return outletName;
	}

	public void setOutletName(String outletName) {
		this.outletName = outletName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public List<Reservation> getReservations() {
		return reservations;
	}

	public void setReservations(List<Reservation> reservations) {
		this.reservations = reservations;
	}

	public Outlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OutletDto convertEntityToDto(Outlet outlet) {
		OutletDto outletDto = new OutletDto();
		return null;
	}

	public static List<OutletDto> convertEntityListToDtoList(List<Outlet> outletList) {

		List<OutletDto> outletDtoList = outletList.stream().map(p -> new OutletDto(p.getOutletName(), p.getLocation())).collect(Collectors.toList());
		return outletDtoList;
	}

}
