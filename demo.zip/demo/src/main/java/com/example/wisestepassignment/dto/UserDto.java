package com.example.wisestepassignment.dto;

import java.util.List;

import com.example.wisestepassignment.entity.Outlet;
import com.example.wisestepassignment.entity.Reservation;
import com.example.wisestepassignment.entity.Trip;
import com.example.wisestepassignment.entity.User;

public class UserDto {
	
	private String userId;
	
	private String userName;
	
	private String location;
	
	private List<Outlet> outlets;
	
	private List<Trip> trips;
	
	private List<Reservation> reservations;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<Outlet> getOutlets() {
		return outlets;
	}

	public void setOutlets(List<Outlet> outlets) {
		this.outlets = outlets;
	}

	public List<Trip> getTrips() {
		return trips;
	}

	public void setTrips(List<Trip> trips) {
		this.trips = trips;
	}

	public List<Reservation> getReservations() {
		return reservations;
	}

	public void setReservations(List<Reservation> reservations) {
		this.reservations = reservations;
	}
	
	public User convertDtoToEntity(UserDto userDto) {
		User userEntity = new User();
		userEntity.setUserName(userDto.getUserName());
		return userEntity;
	}
	
}
